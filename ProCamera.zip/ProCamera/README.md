# Pro Camera — projet CameraX (base)

Ceci est un vrai projet Android natif (Kotlin), pas une app générée par IA. Il utilise CameraX
(l'API caméra recommandée par Google) et couvre 3 modes :

- **PHOTO** — capture standard qualité maximale
- **NUIT** — active l'extension caméra "Night" (fusion multi-images), si le capteur du téléphone
  la supporte matériellement
- **PRO** — contrôle manuel de l'ISO et de la vitesse d'obturation via Camera2Interop

## Comment obtenir un APK à partir de ce projet

Ce dossier ne contient PAS de fichier `.apk` — c'est le code source. Il faut le compiler :

1. Installe **Android Studio** (gratuit) : https://developer.android.com/studio
2. Ouvre ce dossier `ProCamera/` avec "Open an existing project"
3. Laisse Gradle télécharger les dépendances (première ouverture = quelques minutes)
4. Branche ton téléphone (mode développeur + débogage USB activé), ou lance un émulateur
5. Clique sur ▶️ Run — l'app s'installe et se lance directement
6. Pour obtenir un fichier `.apk` installable ailleurs : menu **Build → Build Bundle(s) / APK(s) → Build APK(s)**
   → le fichier apparaît dans `app/build/outputs/apk/debug/`

## Prochaines étapes possibles

- Capture RAW (DNG) — le bouton existe dans l'UI mais n'est pas encore branché
- Vrai traitement HDR+ multi-frame maison (au lieu de dépendre du support Extensions du téléphone)
- Filtres/LUT comme dans LMC
- Mode vidéo avec stabilisation (CameraX VideoCapture)

Dis-moi lequel tu veux ajouter en premier.

package com.procamera.app

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.MediaStore
import android.widget.SeekBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.camera2.interop.Camera2CameraInfo
import androidx.camera.camera2.interop.Camera2Interop
import androidx.camera.camera2.interop.ExperimentalCamera2Interop
import androidx.camera.core.*
import androidx.camera.extensions.ExtensionMode
import androidx.camera.extensions.ExtensionsManager
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.procamera.app.databinding.ActivityMainBinding
import java.text.SimpleDateFormat
import java.util.Locale
import android.hardware.camera2.CaptureRequest

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var imageCapture: ImageCapture? = null
    private var cameraProvider: ProcessCameraProvider? = null
    private var extensionsManager: ExtensionsManager? = null
    private var camera: Camera? = null
    private var lensFacing = CameraSelector.LENS_FACING_BACK
    private var currentMode = Mode.PHOTO

    // Manual control ranges, populated once the camera characteristics are known
    private var isoRange: android.util.Range<Int>? = null
    private var shutterRangeNanos: android.util.Range<Long>? = null

    enum class Mode { PHOTO, NIGHT, PRO }

    private val requestPermissionLauncher =
        registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) startCamera() else {
                Toast.makeText(this, "Permission caméra requise", Toast.LENGTH_LONG).show()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            == PackageManager.PERMISSION_GRANTED
        ) {
            startCamera()
        } else {
            requestPermissionLauncher.launch(Manifest.permission.CAMERA)
        }

        binding.captureButton.setOnClickListener { takePhoto() }
        binding.switchCameraButton.setOnClickListener { switchCamera() }

        binding.modePhoto.setOnClickListener { selectMode(Mode.PHOTO) }
        binding.modeNight.setOnClickListener { selectMode(Mode.NIGHT) }
        binding.modePro.setOnClickListener { selectMode(Mode.PRO) }

        setupProSliders()
    }

    private fun selectMode(mode: Mode) {
        currentMode = mode
        binding.proControls.visibility = if (mode == Mode.PRO) android.view.View.VISIBLE else android.view.View.GONE

        binding.modePhoto.setTextColor(if (mode == Mode.PHOTO) 0xFFFFFFFF.toInt() else 0xFFAAAAAA.toInt())
        binding.modeNight.setTextColor(if (mode == Mode.NIGHT) 0xFFFFFFFF.toInt() else 0xFFAAAAAA.toInt())
        binding.modePro.setTextColor(if (mode == Mode.PRO) 0xFFFFFFFF.toInt() else 0xFFAAAAAA.toInt())

        startCamera()
    }

    private fun startCamera() {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)
        cameraProviderFuture.addListener({
            cameraProvider = cameraProviderFuture.get()
            ExtensionsManager.getInstanceAsync(this, cameraProvider!!).addListener({
                extensionsManager = ExtensionsManager.getInstanceAsync(this, cameraProvider!!).get()
                bindUseCases()
            }, ContextCompat.getMainExecutor(this))
        }, ContextCompat.getMainExecutor(this))
    }

    @androidx.annotation.OptIn(ExperimentalCamera2Interop::class)
    private fun bindUseCases() {
        val provider = cameraProvider ?: return

        val preview = Preview.Builder().build().also {
            it.setSurfaceProvider(binding.viewFinder.surfaceProvider)
        }

        var baseSelector = CameraSelector.Builder().requireLensFacing(lensFacing).build()

        // Night mode: use CameraX Extensions if the device supports it (multi-frame HDR/night fusion)
        if (currentMode == Mode.NIGHT && extensionsManager != null) {
            val ext = extensionsManager!!
            if (ext.isExtensionAvailable(baseSelector, ExtensionMode.NIGHT)) {
                baseSelector = ext.getExtensionEnabledCameraSelector(baseSelector, ExtensionMode.NIGHT)
            } else {
                Toast.makeText(this, "Mode nuit non supporté par ce capteur, capture standard utilisée", Toast.LENGTH_SHORT).show()
            }
        }

        val captureBuilder = ImageCapture.Builder()
            .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)

        // Pro mode: expose manual ISO / shutter speed via Camera2Interop extender
        if (currentMode == Mode.PRO) {
            val extender = Camera2Interop.Extender(captureBuilder)
            val iso = isoRange
            val shutter = shutterRangeNanos
            if (iso != null) {
                val manualIso = iso.lower + ((iso.upper - iso.lower) * binding.isoSlider.progress / 100)
                extender.setCaptureRequestOption(CaptureRequest.SENSOR_SENSITIVITY, manualIso)
            }
            if (shutter != null) {
                val manualShutter = shutter.lower + ((shutter.upper - shutter.lower) * binding.shutterSlider.progress / 100)
                extender.setCaptureRequestOption(CaptureRequest.SENSOR_EXPOSURE_TIME, manualShutter)
                extender.setCaptureRequestOption(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_OFF)
            }
        }

        imageCapture = captureBuilder.build()

        try {
            provider.unbindAll()
            camera = provider.bindToLifecycle(this, baseSelector, preview, imageCapture)
            readSensorRanges()
        } catch (exc: Exception) {
            Toast.makeText(this, "Erreur caméra: ${exc.message}", Toast.LENGTH_LONG).show()
        }
    }

    @androidx.annotation.OptIn(ExperimentalCamera2Interop::class)
    private fun readSensorRanges() {
        val cam = camera ?: return
        val camInfo = Camera2CameraInfo.from(cam.cameraInfo)
        isoRange = camInfo.getCameraCharacteristic(android.hardware.camera2.CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE)
        shutterRangeNanos = camInfo.getCameraCharacteristic(android.hardware.camera2.CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE)
    }

    private fun setupProSliders() {
        val listener = object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser && currentMode == Mode.PRO) bindUseCases()
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        }
        binding.isoSlider.setOnSeekBarChangeListener(listener)
        binding.shutterSlider.setOnSeekBarChangeListener(listener)
    }

    private fun switchCamera() {
        lensFacing = if (lensFacing == CameraSelector.LENS_FACING_BACK)
            CameraSelector.LENS_FACING_FRONT else CameraSelector.LENS_FACING_BACK
        startCamera()
    }

    private fun takePhoto() {
        val capture = imageCapture ?: return

        val name = SimpleDateFormat("yyyy-MM-dd-HH-mm-ss-SSS", Locale.US)
            .format(System.currentTimeMillis())

        val contentValues = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/ProCamera")
        }

        val outputOptions = ImageCapture.OutputFileOptions.Builder(
            contentResolver,
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
            contentValues
        ).build()

        capture.takePicture(
            outputOptions,
            ContextCompat.getMainExecutor(this),
            object : ImageCapture.OnImageSavedCallback {
                override fun onError(exc: ImageCaptureException) {
                    Toast.makeText(baseContext, "Échec capture: ${exc.message}", Toast.LENGTH_SHORT).show()
                }

                override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                    Toast.makeText(baseContext, "Photo enregistrée", Toast.LENGTH_SHORT).show()
                }
            }
        )
    }
}
